
public class Laptop {
	
	// Eigenschaften / Attribute
	String marke;
	int ram;
	String cpu;
	double preis;
	
	// Konstruktor
	public Laptop(String marke, int ram, String cpu, double preis){
		this.marke = marke;
		this.ram = ram;
		this.cpu = cpu;
		this.preis = preis;
	}
	
	// Methoden
	public void starten(){
		
	}

}
