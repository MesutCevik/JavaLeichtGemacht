
public  class Auto {

	// Eigenschaften / Attribute
	String marke;
	int ps;
	int tuerenAnzahl;
	String farhzeugTyp;

	// Konstruktoren
	public Auto(String marke, int ps, int tuerenAnzahl, String farhzeugTyp) {
		super();
		this.marke = marke;
		this.ps = ps;
		this.tuerenAnzahl = tuerenAnzahl;
		this.farhzeugTyp = farhzeugTyp;
	}

	// Methoden
	public void starten(){
		System.out.println("Das Auto startet");
	}
	

		
	
		
	
}
