
public class Mainboard {

	// Eigenschaften / Attribute 
	int ramSlots;
	int kartenSlots;
	int usbPorts;
	
	// Konstruktor
	public Mainboard(){
		
	}
	
	public Mainboard(int ramSlots, int kartenSlots, int usbPorts){
		this.ramSlots = ramSlots;
		this.kartenSlots = kartenSlots;
		this.usbPorts = usbPorts;
	}
	
	// Methoden
}
