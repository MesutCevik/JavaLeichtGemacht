
public class AufgabeI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Aufgabe:
		 * 
		 * 1. Auto: 3500
		 * 2. Alter: 18
		 * 3. Vorname: Peter
		 * 4. Nachname: Müller
		 * 
		 * 1. Überlege Dir welchen Datentyp diese Informationen repräsentieren 
		 * 2. Lege Variablen fest und speicher diese Werte in den Variablen ab
		 * 3. Gebe die Werte mit Hilfe von System.out.println(""); aus
		 */
		
		int auto = 3500;
		int alter = 18;
		
		String name = "Peter Müller";
		
		String vorName = "Peter";
		String nachName = "Müller";
		
		System.out.println("Herr " + name + " sein Alter " + alter + " sein Auto kostet: " + auto + "€");
		
		
	}

}
