package beispielpaket;

public class NichtDurchNullTeilenException extends Exception {

	public NichtDurchNullTeilenException(String message){
		super(message);
	}
}
