
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Auto bmw = new Auto();
		bmw.preis = 6000.50;
		bmw.reifen = 4;
		
		int zahl = 4;
		
	}

}
