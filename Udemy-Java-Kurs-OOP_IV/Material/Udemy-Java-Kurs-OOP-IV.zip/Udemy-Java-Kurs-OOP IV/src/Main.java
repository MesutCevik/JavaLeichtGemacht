
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Held player1 = new Held(46);
		// player1.getLebenspunkte();
		//
		// int schaden = 10;
		//
		// player1.setLebenpunkte(schaden);
		GoogleKonto peter = new GoogleKonto("peter123", "1234");

		peter.setPasswort("1234");
		

	
	}

}
