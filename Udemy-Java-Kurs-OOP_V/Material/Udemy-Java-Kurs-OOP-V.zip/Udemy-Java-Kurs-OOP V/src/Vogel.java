
public class Vogel extends Tier {

	@Override
	public void essen() {
		System.out.println("Der Vogel pickt sein essen auf");
		
	}

	@Override
	public void atmen() {
		// TODO Auto-generated method stub
		
	}

}
