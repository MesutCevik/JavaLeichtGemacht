
public class NichtGenerics {

	// Eigenschaften / Attribute
	private int value;

	// Konstruktoren
	public NichtGenerics(int value) {
		this.setValue(value);
	}

	// Methoden
	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
